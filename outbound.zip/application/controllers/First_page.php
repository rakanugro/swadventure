<?php


Class First_page extends CI_controller
{

	function __contruct()
	{
		parent__::construct();
	}

	function index()
	{

		$data = array(
			"title" => "Outbound",


		);
		$this->load->view('template', $data);
	}



}