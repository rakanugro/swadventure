<header class="site-header wow fadeInDown">
				<div class="container">
					<div class="header-content">
						<div class="branding">
							<img src="<?php base_url() ?>assets/outbound/images/logo.png" alt="Company Name" class="logo">
							<h1 class="site-title"><a href="index.html">Company Name</a></h1>
							<small class="site-description">Tagline goes here</small>
						</div>
						
						<nav class="main-navigation">
							<button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
							<ul class="menu">
								<li class="menu-item"><a href="about-us.html">About us</a></li>
								<li class="menu-item"><a href="our-offer.html">Our Offer</a></li>
								<li class="menu-item"><a href="customer-protection.html">Customer Protection</a></li>
								<li class="menu-item"><a href="contact.html">Contact</a></li>
							</ul>
						</nav>
						
						<div class="social-links">
							<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
							<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
							<a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
							<a href="#" class="pinterest"><i class="fa fa-pinterest"></i></a>
						</div>
					</div>
				</div>
			</header> <!-- .site-header -->
